Akaya is a single weight experimental display typeface in Kannada, Telugu and Latin scripts. Akaya Telivigala and [Akaya Kanadaka](/specimen/Akaya+Kanadaka) are made as two separate font files which share a common Latin.

To contribute, please see [github.com/vaishnavimurthy/Akaya-Telivigala](https://github.com/vaishnavimurthy/Akaya-Telivigala).